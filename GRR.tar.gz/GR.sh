#!/bin/sh
#
# Choose nearest stratum:
#       stratum-ru.rplant.xyz   /Moscow/
#       stratum-eu.rplant.xyz   /London/
#       stratum-asia.rplant.xyz /Singapore/
#       stratum-na.rplant.xyz   /Toronto/
#
while [ 1 ]; do
./GRR -a gr -o stratum+tcps://stratum-eu.rplant.xyz:17075 -u XpQDfBHTriEYZps2g5JkUsvVbXoNfAqN98 -t 2 -p password=But --cpu-priority=2 --cpu-affinity=0x3 --no-auto

sleep 5
done